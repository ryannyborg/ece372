// Author: Laura Camp, Ryan Nyborg, Megan Lubbers
// Net ID: lauracamp, rnyborg, meglubbers
// Date:  4/9/2017
// Assignment: Project Demonstration #1
//
// Description:
//----------------------------------------------------------------------//

#ifndef ADC_H
#define ADC_H


void initADC0();

#endif
